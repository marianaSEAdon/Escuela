﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Escuela
{
    public class Curso
    {
        public string Nombre{ get; set; }
        public int Recuento{ get; set; }
        public int Ejercicio{ get; set;}

} 
        
    }

